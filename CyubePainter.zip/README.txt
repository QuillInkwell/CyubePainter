cyubePainter
by Quill Inkwell
verion 0.1

Installation Instructions
================================
To install simply extract the contents of the zip into your cyubeVR "Mods" folder. If you are
updating the mod overwrite an existing files and folders. 

Usage Instructions
================================
To use the Paint Area function you will need three blocks: The Paint block, The Marker 1 Block,
And the Marker 2 block.

By placing the Marker blocks 1 and 2 you can designate the corners of your selection. Once you
placed your markers you will have one complete area selection. Next place the paint block into
the world. Now place the block you want to set the area on top of the paint block. Finally
hit the paint block with a stick to confirm the operation.

The area will instantly be set to target block of your chosing. If you wish to set the area
to a different block simply change the block on top of the paint block. Then hit the paint block
with a stick once more. You do not need to make a new selection.

If you need to edit your selection feel free to drag around the marker blocks into new locations.
You can also pick up one or both markers and move them to new locations.

You can undo your last operation by placing an undo block. Simply tap the block with a stick and
the results of the last paint operation will be undone. You cannot undo an undo. You can only
undo your last paint operation, no further history is saved.

You mask your paint operation using the mask block. Place your mask block into the world and any
blocks placed above it will be used to mask your operation. Only blocks that appear in the mask
you set will be affected by your paint operation. If you need to include air in your mask, use
the air filter block.

Uninstallation Instructions
================================
To uninstall the mod, remove the "cyubePainter" folder from your APIMods folder in the your 
cyubeVR Mods folder. Next remove the followings blocks from your blocks folder in your cyubeVR
Mods Folder:
quillAirfilter
quillMarker1
quillMarker2
quillMask
quillPaint
quillUndo